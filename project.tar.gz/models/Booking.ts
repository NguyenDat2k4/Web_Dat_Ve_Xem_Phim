import mongoose from 'mongoose'

const BookingSchema = new mongoose.Schema({
  cinema: {
    type: String,
    required: [true, 'Please provide the cinema.'],
  },
  movie: {
    type: String,
    required: [true, 'Please provide the movie.'],
  },
  date: {
    type: String,
    required: [true, 'Please provide the date.'],
  },
  time: {
    type: String,
    required: [true, 'Please provide the time.'],
  },
  seats: {
    type: [String],
    default: [],
  },
  totalPrice: {
    type: Number,
    default: 0,
  },
  customerName: {
    type: String,
    default: '',
  },
  customerPhone: {
    type: String,
    default: '',
  },
  userEmail: {
    type: String,
    default: '', // Store the logged-in user's email if available
  },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'cancelled', 'paid'],
    default: 'confirmed',
  },
  paymentMethod: {
    type: String,
    default: '',
  },
  pointsUsed: {
    type: Number,
    default: 0,
  },
  combos: [{
    name: String,
    price: Number,
    quantity: Number
  }],
  ticketCode: {
    type: String,
    unique: true
  },
  paymentId: {
    type: String,
    default: ''
  },
  checkInStatus: {
    type: Boolean,
    default: false
  },
  checkInAt: {
    type: Date
  },
  isGift: {
    type: Boolean,
    default: false
  },
  recipientName: String,
  recipientEmail: String,
  giftMessage: String,
  giftTemplate: String,
  isMystery: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true,
})


// Clear cached model to ensure fresh schema
if (mongoose.models.Booking) {
  mongoose.deleteModel('Booking')
}

export default mongoose.models.Booking || mongoose.model('Booking', BookingSchema)
