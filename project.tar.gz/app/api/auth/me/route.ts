import { NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import dbConnect from '@/lib/mongodb'
import User from '@/models/User'

export async function GET() {
  const session = await getSession()
  if (!session) {
    return NextResponse.json({ user: null })
  }

  await dbConnect()
  const user = await User.findById(session.user.id).select('-password')
  if (!user) {
    return NextResponse.json({ user: null })
  }

  return NextResponse.json({ user })
}
