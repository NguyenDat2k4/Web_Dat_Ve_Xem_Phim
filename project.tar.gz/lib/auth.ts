import { SignJWT, jwtVerify } from 'jose'
import { cookies } from 'next/headers'
import { NextRequest, NextResponse } from 'next/server'

const secretKey = 'secret' // In a real app, use an environment variable
const key = new TextEncoder().encode(secretKey)

export async function encrypt(payload: any) {
  return await new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('2h')
    .sign(key)
}

export async function decrypt(input: string): Promise<any> {
  const { payload } = await jwtVerify(input, key, {
    algorithms: ['HS256'],
  })
  return payload
}

export async function login(user: any) {
  // Create the session
  const expires = new Date(Date.now() + 2 * 60 * 60 * 1000)
  const session = await encrypt({ user, expires })

  // Save the session in a cookie
  ;(await cookies()).set('session', session, { expires, httpOnly: true })
}

export async function logout() {
  // Destroy the session
  ;(await cookies()).set('session', '', { expires: new Date(0) })
}

export async function getSession() {
  const session = (await cookies()).get('session')?.value
  if (!session) return null
  try {
    const parsed = await decrypt(session)
    
    // Extremely robust normalization for user ID
    if (parsed?.user?.id) {
      const id = parsed.user.id
      if (typeof id === 'string') {
        parsed.user.id = id
      } else if (typeof id === 'object') {
        // Handle Mongoose ObjectId serialized as { buffer: { '0': ... } }
        if (id.buffer && typeof id.buffer === 'object') {
          const bufferValues = Object.values(id.buffer) as number[]
          if (bufferValues.length === 12) {
            parsed.user.id = bufferValues
              .map(b => b.toString(16).padStart(2, '0'))
              .join('')
          } else {
            parsed.user.id = id.toString()
          }
        } else {
          parsed.user.id = id.toString()
        }
      }
    }
    
    return parsed
  } catch (e) {
    console.error("Session decryption/normalization failed:", e)
    return null
  }
}

export async function updateSession(request: NextRequest) {
  const session = request.cookies.get('session')?.value
  if (!session) return

  // Refresh the session so it doesn't expire
  const parsed = await decrypt(session)
  parsed.expires = new Date(Date.now() + 2 * 60 * 60 * 1000)
  const res = NextResponse.next()
  res.cookies.set({
    name: 'session',
    value: await encrypt(parsed),
    httpOnly: true,
    expires: parsed.expires,
  })
  return res
}
